package com.example.currread;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;

import com.example.currread.Adapter.crAdapter;
import com.example.currread.Model.crModel;
import com.example.currread.Utils.DataBase;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class MainActivity extends AppCompatActivity implements OnDialogCloseListener {
    private RecyclerView rec;
    private FloatingActionButton fab;
    private DataBase db;
    private List<crModel> mList;
    private crAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rec = findViewById(R.id.recyclerview);
        fab = findViewById(R.id.fab);
        db = new DataBase(MainActivity.this);
        mList = new ArrayList<>();
        adapter = new crAdapter(db , MainActivity.this);

        rec.setHasFixedSize(true);
        rec.setLayoutManager(new LinearLayoutManager(this));
        rec.setAdapter(adapter);

        mList = db.getAllTasks();
        Collections.reverse(mList);
        adapter.setItems(mList);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddNewItem.newInstance().show(getSupportFragmentManager() , AddNewItem.TAG);
            }
        });
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new RecyclerViewTouch(adapter));
        itemTouchHelper.attachToRecyclerView(rec);
    }
    @Override
    public void onDialogClose(DialogInterface dialogInterface) {
        mList = db.getAllTasks();
        Collections.reverse(mList);
        adapter.setItems(mList);
        adapter.notifyDataSetChanged();
    }
}