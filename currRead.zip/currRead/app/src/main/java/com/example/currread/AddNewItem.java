package com.example.currread;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.text.Editable;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.core.content.ContextCompat;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.currread.Model.crModel;
import com.example.currread.Utils.DataBase;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
public class AddNewItem extends BottomSheetDialogFragment {
    public static final String TAG = "AddNewItem";
    private Button mSbtn;
    private EditText newJudul, newStatus, newTochap, newCurchap, newAlur, newBurl;

    private DataBase db;

    public static AddNewItem newInstance(){
        return new AddNewItem();
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.add_items , container , false);
        return v;
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        newJudul = view.findViewById(R.id.newjudul);
        newStatus = view.findViewById(R.id.newstatus);
        newTochap = view.findViewById(R.id.newtochap);
        newCurchap = view.findViewById(R.id.newcurchap);
        newAlur = view.findViewById(R.id.newalur);
        newBurl = view.findViewById(R.id.newburl);
        mSbtn = view.findViewById(R.id.sbtn);

        db = new DataBase(getActivity());
        boolean isUpdate = false;

        Bundle bundle = getArguments();
        if (bundle != null) {
            isUpdate = true;
            String judul = bundle.getString("judul");
            String status = bundle.getString("status");
            int tochap = bundle.getInt("tochap");
            int curchap = bundle.getInt("curchap");
            String alur = bundle.getString("alur");
            String burl = bundle.getString("burl");

            setEdit(newJudul);
            setEdit(newStatus);
            setEdit(newTochap);
            setEdit(newCurchap);
            setEdit(newAlur);
            setEdit(newBurl);

            if (!judul.isEmpty() || !status.isEmpty() || tochap > 0 || curchap > 0 || !alur.isEmpty() || !burl.isEmpty()) {
                mSbtn.setEnabled(false);
            }
        }
        final boolean finalUpdate = isUpdate;
        mSbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String judulText = newJudul.getText().toString();
                String statusText = newStatus.getText().toString();
                int tochapValue = Integer.parseInt(newTochap.getText().toString());
                int curchapValue = Integer.parseInt(newCurchap.getText().toString());
                String alurText = newAlur.getText().toString();
                String burlText = newBurl.getText().toString();

                if (finalUpdate) {
                    db.updateJudul(bundle.getInt("id"), judulText);
                    db.updateStatus(bundle.getInt("id"), statusText);
                    db.updateTochap(bundle.getInt("id"), tochapValue);
                    db.updateCurchap(bundle.getInt("id"), curchapValue);
                    db.updateAlur(bundle.getInt("id"), alurText);
                    db.updateBurl(bundle.getInt("id"), burlText);
                } else {
                    crModel item = new crModel();
                    item.setJudul(judulText);
                    item.setStatus(statusText);
                    item.setTochap(tochapValue);
                    item.setCurchap(curchapValue);
                    item.setAlur(alurText);
                    item.setBurl(burlText);
                    item.setValid(0);
                    db.insertItem(item);
                }
                dismiss();
            }
        });
    }

    private void setEdit(final EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkEmptyEditTexts();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void checkEmptyEditTexts() {
        boolean isAnyEditTextEmpty = newJudul.getText().toString().isEmpty() ||
                newStatus.getText().toString().isEmpty() ||
                newTochap.getText().toString().isEmpty() ||
                newCurchap.getText().toString().isEmpty() ||
                newAlur.getText().toString().isEmpty() ||
                newBurl.getText().toString().isEmpty();

        if (isAnyEditTextEmpty) {
            mSbtn.setEnabled(false);
            mSbtn.setBackgroundColor(Color.GRAY);
        } else {
            int color1 = ContextCompat.getColor(requireContext(), R.color.color1);
            mSbtn.setEnabled(true);
            mSbtn.setBackgroundColor(color1);
        }
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        Activity activity = getActivity();
        if (activity instanceof OnDialogCloseListener){
            ((OnDialogCloseListener)activity).onDialogClose(dialog);
        }
    }
}
