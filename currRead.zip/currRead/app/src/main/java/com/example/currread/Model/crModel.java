package com.example.currread.Model;

public class crModel {
    private  String judul,status,alur,burl;
    private int id,valid,tochap,curchap;

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAlur() {
        return alur;
    }

    public void setAlur(String alur) {
        this.alur = alur;
    }

    public String getBurl() {
        return burl;
    }

    public void setBurl(String burl) {
        this.burl = burl;
    }

    public int getTochap() {
        return tochap;
    }

    public void setTochap(int tochap) {
        this.tochap = tochap;
    }

    public int getCurchap() {
        return curchap;
    }

    public void setCurchap(int curchap) {
        this.curchap = curchap;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getValid() {
        return valid;
    }

    public void setValid(int valid) {
        this.valid = valid;
    }
}
