package com.example.currread.Adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.currread.AddNewItem;
import com.example.currread.MainActivity;
import com.example.currread.Model.crModel;
import com.example.currread.R;
import com.example.currread.Utils.DataBase;
import de.hdodenhof.circleimageview.CircleImageView;
import com.bumptech.glide.Glide;
import java.util.List;

public class crAdapter extends RecyclerView.Adapter<crAdapter.MyViewHolder> {
    private List<crModel> mList;
    private MainActivity activity;
    private DataBase db;
    CircleImageView img;
    public crAdapter(DataBase db , MainActivity activity){
        this.activity = activity;
        this.db = db;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.items , parent , false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final crModel item = mList.get(position);
        holder.chkBox.setText("Ini bacaan " + (position + 1));
        holder.textJudul.setText(item.getJudul());
        holder.textStatus.setText(item.getStatus());
        holder.tochaptext.setText("Total Chapter: " + item.getTochap());
        holder.curchaptext.setText("Chapter Dibaca: " + item.getCurchap());
        holder.alurtext.setText("Gambaran Alur: " + item.getAlur());
        Glide.with(holder.img.getContext())
                .load(item.getBurl())
                .placeholder(R.drawable.ic_launcher_background)
                .circleCrop()
                .error(R.drawable.ic_launcher_foreground)
                .into(holder.img);
        holder.chkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    db.updateValid(item.getId() , 1);
                }else
                    db.updateValid(item.getId() , 0);
            }
        });
    }

    public boolean toBoolean(int num){
        return num!=0;
    }

    public Context getContext(){
        return activity;
    }

    public void setItems(List<crModel> mList) {
        this.mList = mList;
        notifyDataSetChanged();
    }

    public void editItem(int position){
        crModel item = mList.get(position);
        Bundle bundle = new Bundle();
            bundle.putInt("id", item.getId());
            bundle.putInt("tochap", item.getTochap());
            bundle.putInt("Curchap", item.getCurchap());
            bundle.putInt("Desc", item.getValid());
            bundle.putString("judul", item.getJudul());
            bundle.putString("status", item.getStatus());
            bundle.putString("Alur", item.getAlur());
            bundle.putString("Burl", item.getBurl());

            AddNewItem task = new AddNewItem();
            task.setArguments(bundle);
            task.show(activity.getSupportFragmentManager(), task.getTag());
    }


    public void deleteItem(int position){
        crModel item = mList.get(position);
        db.deleteItem(item.getId());
        mList.remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        CheckBox chkBox;
        CircleImageView img;
        TextView textJudul, textStatus, tochaptext, curchaptext, alurtext;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            chkBox = itemView.findViewById(R.id.chkbox);
            textJudul = itemView.findViewById(R.id.judultext);
            textStatus = itemView.findViewById(R.id.statustext);
            tochaptext = itemView.findViewById(R.id.tochaptext);
            curchaptext = itemView.findViewById(R.id.curchaptext);
            alurtext = itemView.findViewById(R.id.alurtext);
            img = (CircleImageView)itemView.findViewById(R.id.img1);
        }
    }
}
